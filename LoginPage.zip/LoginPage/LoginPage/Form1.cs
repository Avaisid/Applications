﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LoginPage
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            SqlConnection con = new SqlConnection("Data Source=DESKTOP-82S2JV4\\SQLEXPRESSWIN10;Initial Catalog=avais;Persist Security Info=True;User ID=as1;Password =sql12345");
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from login_table where username = '"+textBox1.Text+"'and password = '"+textBox2.Text+"'" ,con);
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            int count = 0;
            while(dr.Read())
            {
                count += 1;

            }
            if(count==1)
            {
                MessageBox.Show("ok");
                Form2 f2 = new Form2();
                f2.Show();
            }
            else if(count>0)
            {
                MessageBox.Show("Duplicate Enrty Username or Password");
            }
            else
            {
                MessageBox.Show("Invalid Username or Password");
            }

            textBox1.Clear();
            textBox2.Clear();
        }
    }
}
 